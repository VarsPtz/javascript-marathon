// let choosePets;
// let chooseEntertainments;

let getName = prompt("Как Вас зовут?");
let choosePets = prompt("Кто Вам больше нравятся: кошки или собаки?");
let chooseEntertainments = prompt("Что Вы любите делать вместе с Вашим домашним питомцем? (гулять, играть, купаться и т.п.)");
console.log("Вам больше нравятся " + choosePets + ".");
console.log("C Вашии домашним питомцем вы любите: " + chooseEntertainments + ".");
alert(getName + ", cпасибо за Ваши ответы!");